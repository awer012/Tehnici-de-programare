# Modul cu functii reutilizabile pentru lucrul cu site-uri web
# Student: Burlea Amelia

import requests
import time
import json
import re
import socket
import ssl
import urllib.parse

TIMEOUT = 10  # secunde
DEFAULT_HEADERS = {"User-Agent": "WebLab-Burlea-Amelia"} 

def fetch(url, timeout=10):
    """Returneaza obiectul raspuns pentru adresa url."""
    return requests.get(url,headers=DEFAULT_HEADERS, timeout=timeout)


def get_status(url):
    """Returneaza codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code


def get_title(html):
    """Returneaza titlul paginii dintr-un text HTML."""
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")
    return html[start:end].strip()


def security_headers(url):
    """Returneaza {antet: True/False} pentru cele 5 antete de securitate."""
    list_of_headers = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy",
    ]
    result = {}
    response = requests.get(url, timeout=TIMEOUT)
    for name in list_of_headers:
        result[name] = name in response.headers
    return result

def check_paths(base, paths):
    """Returneaza un dictionar {cale: cod_de_stare} pentru fiecare cale din lista."""
    result = {}
    for path in paths:
        r = requests.get(base + path, timeout=TIMEOUT)
        result[path] = r.status_code
        time.sleep(1)
    return result

def resolve(hostname):
    """Returneaza adresa IP a domeniului hostname."""
    return socket.gethostbyname(hostname)

def score_headers(results):
    """Primeste {antet: True/False} si returneaza un sir 'prezente/total'."""
    return f"{sum(results.values())}/{len(results)}"


def extract_links(html):
    """Returneaza legaturile de pe pagina, fara duplicate."""
    links = re.findall(r'href="([^"]+)"', html)
    return list(dict.fromkeys(links))


def split_links(links, domain):
    """Returneaza legaturile interne si cele externe."""
    interne = []
    externe = []
    for link in links:
        complet = urllib.parse.urljoin("https://" + domain, link)
        if urllib.parse.urlparse(complet).netloc == domain:
            interne.append(complet)
        else:
            externe.append(complet)
    return interne, externe


def fetch_robots(base):
    """Returneaza textul fisierului /robots.txt sau None daca lipseste."""
    try:
        response = requests.get(base + "/robots.txt", timeout=TIMEOUT)
    except requests.RequestException:
        return None
    if response.status_code == 200:
        return response.text
    return None


def disallowed_paths(robots_text):
    """Returneaza lista cu valorile Disallow: din robots.txt."""
    result = []
    if robots_text is None:
        return result
    for linie in robots_text.splitlines():
        if linie.startswith("Disallow:"):
            result.append(linie.split(":")[1].strip())
    return result


def cert_days_left(hostname):
    """Returneaza zilele ramase pana la expirarea certificatului."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as secure_sock:
            cert = secure_sock.getpeercert()
    expira = ssl.cert_time_to_seconds(cert["notAfter"])
    return int((expira - time.time()) // 86400)


def site_report(url):
    """Returneaza un raport despre url, il afiseaza si il salveaza in report.json."""
    host = urllib.parse.urlparse(url).netloc
    r = fetch(url)
    interne, externe = split_links(extract_links(r.text), host)
    time.sleep(1)
    redir = requests.get("http://" + host, timeout=TIMEOUT).history
    time.sleep(1)
    scor = score_headers(security_headers(url))
    time.sleep(1)
    zile = cert_days_left(host)
    time.sleep(1)
    cai = disallowed_paths(fetch_robots(url))

    raport = {
        "Cod de stare: ": r.status_code,
        "Titlu: ": get_title(r.text),
        "Adresa IP: ": resolve(host),
        "Redirectionari: ": ", ".join(f"{x.status_code} -> {x.headers.get('Location')}" for x in redir) or "niciuna",
        "Scor securitate: ": scor,
        "Certificat: ": f"{zile} de zile ramase",
        "Legaturi: ": f"{len(interne)} interne, {len(externe)} externe",
        "Cai interzise: ": ", ".join(cai) or "niciuna",
    }

    print(f"=== Raport site: {url} ===")
    for cheie, valoare in raport.items():
        print(cheie + str(valoare))
    with open("report.json", "w") as file:
        json.dump(raport, file, indent=2)
    print("Salvat in report.json")
    return raport

if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))
