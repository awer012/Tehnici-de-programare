# Laborator: funcții, metode și importuri pe web
# Student: Burlea Amelia

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde
import time

# Exercițiul 1. Primul import
import requests
print(requests.__version__)
import urllib.request
# requests este o biblioteca externa ce nu face parte din biblioteca standard Python
# urllib este o biblioteca preinstalata si face parte din biblioteca standard Python

#Execitiul 2. Doua stiluri de import
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare ex2 import request:", response.status_code)
time.sleep(1)
from requests import get
response_2 = get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare ex 2 from requests import get:", response_2.status_code)
time.sleep(1)
#avantaj pentru scriere main lunga: iti dai seama din ce modul provine functia
#avantaj pentru scriere scurta: codul este mai scurt pentru ca este aplicata direct functia

# Exercitiul 3. Alias-uri
import requests as rq
response_alias = rq.get(BASE_URL, timeout=TIMEOUT)
time.sleep(1)
print("Cod de stare ex 3 import request as rq:", response_alias.status_code)
#Alias-ul face codul mai usor de citit in situatii cand codul foloseste biblioteci cu un nume lung, iar repetarea acestuia este grea si costisitoare in timp
#Alias-ul face codul mai greu de citit probabil in cazul in care cinvea citeste codul si scapa linia in care se atribuie alias-ul

# Exercițiul 4. Doar biblioteca standard
import urllib.request
parameters={'User-Agent': 'Mozilla/5.0'}
req = urllib.request.Request(BASE_URL, headers=parameters)
time.sleep(1)
response_std = urllib.request.urlopen(req)

print("Cod de stare ex 4 urllib:", response_std.status)

html_body = response_std.read().decode("utf-8")
print("Primele 200 caractere din corp:")
print(html_body[:200])

#Exercitiul 5. Priviti in interiorul unui modul
print(dir(requests))  #pentru a privi interiorul modului reqeuests
print(type(requests.get))  #get este o functie
print(type(requests.Session))  #Session este o clasa
print(type(requests.exceptions))  #exception este un modul

#Exercitiul 6. Cititi documentatia
help(requests.get) #gasirea parametrului pt timp maxim (timeout)
response_timeout=requests.get(BASE_URL, timeout=TIMEOUT)

print("Timeout reusit ex 6:", response_timeout.status_code)
time.sleep(1)

#Exercitiul 7. Cronometarea unei cereri
import time
start_time = time.perf_counter()
response_timer = requests.get(BASE_URL, timeout=TIMEOUT)
time.sleep(1)
end_time = time.perf_counter()
durata = end_time - start_time
print("ex 7 Timplu masurat in secunde de mine:",durata)
print("ex 7 Timpul masurat de requests:", response_timer.elapsed) 

#Exercitiul 8. Cand un import esueaza
try: 
	import bs4
except ImportError:
	print("Instalati modulul cu: pip install beautifulsoup4.")

#Un modul este un Python file cu extensia .py
#Un pachet este un folder ce contine unul sau mai multe module 
#O biblioteca este o multime de pachete sau module
