#Laborator: functii, metode si importuri web
#Student: Burlea Amelia

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import time
import requests

print("\nEX 21")

#Exercitiul 21. Prima functie
def fetch(url: str) -> int:
	"""Returneaza obiectul raspuns"""
	response = requests.get(url, timeout=TIMEOUT)
	return response
response=fetch(BASE_URL)
print(response.status_code)
time.sleep(1)
print("\nEX 22")

#Exercitiul 22. Returnarea unei singure valori
def get_status(url: str) ->int:
	"""Returneaza codul de stare a siteului"""
	response= requests.get(url, timeout=TIMEOUT)
	return response.status_code
robots = get_status(BASE_URL + "/robots.txt")
time.sleep(1)
sitemap = get_status(BASE_URL + "/sitemap.xml")
time.sleep(1)
principala= get_status(BASE_URL + "/")
time.sleep(1)
print("Cod de stare /robots.txt: ",robots)
print("Cod de stare /sitemap.xml: ", sitemap)
print("Cod de stare /: ", principala)
print("\nEX 23")

#Exercitiul 23. Parametrii impliciti
def fetch_2(url :str, timeout=10) -> str:
	"""Returneza obiectul raspuns si are valoare implicita timeout"""
	response = requests.get(url, timeout=timeout)
	return response
response = fetch_2(BASE_URL)
time.sleep(1)
response_2 = fetch_2(BASE_URL, timeout=3)
print("Apelare cu valoare implicita: ", response)
print("Apelare cu timeout=3", response_2)
print("\nEX 24")

#Exercitiul 24.O singura sarcina pe funcite
def get_title(html: str) -> str:
	"""Returneaza titlul documentului html."""
	start = html.find("<title>") + len("<title>")
	end = html.find("</title>")
	return html[start:end].strip()
time.sleep(1)
response = fetch(BASE_URL)
titlu = get_title(response.text)
print("Titlul paginii este: ", titlu)
print("\nEX 25")

#Exercitiul 25.Docstring-uri
help(get_title)
print("\nEX 26")

#Exercitiul 26. Adnotari de tip
try:
	get_title(123)
except Exception:
	print("Eroare")
#Adnotarile de tip nu opresc programul pentru ca python nu le verifica la rularea codului, ele doar sunt indicatii pentru citirea mai usoara a codului
print("\nEX 27")

#Exercitiul 27.Fara opriri neasteptate
def page_exists(url: str) -> bool:
	"""Returneaza True daca pagina exista si daca nu exista returneaza False"""
	try:
		response = requests.get(url, timeout=TIMEOUT)
		return response.ok
	except requests.RequestException:
		return False
time.sleep(1)
print(page_exists(BASE_URL))
time.sleep(1)
print(page_exists("https://this-domain-does-not-exist.invalid"))
print("\nEX 28")

#Exercitiul 28. Retunarea unui dictionar
def check_paths(base: str, paths: list):
	"""Returneaza statutul pentru fiecare cale dintr-o lista"""
	path_dict={}
	for path in paths:
		response=requests.get(base + path, timeout=TIMEOUT)
		path_dict[path]=response.status_code
		time.sleep(1)
	return path_dict
rezultat=check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"])
print(rezultat)
print("\nEX 29")

#Exercitiul 29.Argumente cu nume
def get_header(url, name, default="lipseste"):
	"""Returneaza valoarea unui singur antet"""
	response = requests.get(url, timeout= TIMEOUT)
	return response.headers.get(name, default)

time.sleep(1)
print(get_header(BASE_URL, name="Server"))
print("\nEX 30")

#Exercitiul 30.Antete de securitate
def security_headers(url):
	"""Verifica prezenta urmatoarelor antete: Strict-Transport-Security,Content-Security-Policy,X-Frame-Options,X-Content-Type-Options,Referrer-Policy"""

	headers_dict = {}
	list_of_headers = ["Strict-Transport-Security","Content-Security-Policy","X-Frame-Options","X-Content-Type-Options", "Referrer-Policy"]
	response=requests.get(url, timeout=TIMEOUT)
	for name in list_of_headers:
		headers_dict[name] = name in response.headers
	return headers_dict
time.sleep(1)
print(security_headers(BASE_URL))
print("\nEX 31")

#Exercitiul 31.Functii care apeleaza la functii
def score_headers(results):
	"""Primeste dictionarul din functia security_headers si afiseaza cate antete sunt prezente din numarul total"""
	prezenta = sum(results.values())
	total = len(results)
	return f"{prezenta}/{total}"
print(score_headers(security_headers(BASE_URL)))
print("\nEX 32")

#Exercitiul 32. Doua functii, o sarcina
def fetch_robots(base):
	"""Returneaza textul fisierului /robots/txt daca el exista sau None daca fisierul lipseste"""
	try:
		response = requests.get(base + "/robots.txt", timeout= TIMEOUT)
	except requests.RequestException:
		return None
	if response.status_code == 200:
		return response.text
	else:
		return None
def disallowed_paths(robots_text):
	"""Returneaa o lista cu toate valorile Disslaow:"""
	list_dissalow=[]
	if robots_text is None:
		return list_dissalow
	for linie in robots_text.splitlines():
		if linie.startswith("Disallow"):
			valoare = linie.split(":")[1].strip()
			list_dissalow.append(valoare)
	return list_dissalow

print(disallowed_paths("User-agent: *\nDisallow: /admin/\nDisallow: /private/"))
print(disallowed_paths(None))

time.sleep(1)
print(disallowed_paths(fetch_robots(BASE_URL)))
print("\nEX 33")

#Exercitiul 33. Oricate argumente
def response_times(*urls):
	"""Poate primi mai mule urls si returneaza un dictionar cu timpul in secunde de executare"""
	dictionar={}
	for url in urls:
		response = requests.get(url, timeout=TIMEOUT)
		secunde = response.elapsed.total_seconds()
		dictionar[url] = secunde
		time.sleep(1)
	return dictionar
print(response_times(BASE_URL, BASE_URL + "/robots.txt"))
print("\nEX 34")

#Exercitiul 34.Argumente cu nume colectate
def log(message, **details):
	"""Primeste un message si alte detallii care le afiseaza urmat de fiecare detaliu"""
	linie = message
	for cheie, valoare in details.items():
		linie+= f"| {cheie}={valoare}"
	print(linie)
log("verificat", url=BASE_URL, status =200)
#print doar afiseaza valoarea, pe cand return trimite inapoi valoarea de unde a fost apelata functia ca programul sa o poata folosi mai departe
