#Laborator: functii, metode si importuri web
#Student: Burlea Amelia

import requests 
import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde
print("\nEX 9")

#Exercitiul 9. Elemente de baza a raspunsului
response = requests.get(BASE_URL, timeout=TIMEOUT)
time.sleep(1)
print(response.status_code) #atribut
print(response.ok) #atribut
print(response.url) #atribut
print(response.encoding) #atribut
print("\nex 10")

#Exercitiul 10. Tratarea erorilor cu o metoda
time.sleep(1)
try:
	response_404 = requests.get(BASE_URL + "/this-page-does-not-exist", timeout = TIMEOUT)
	response_404.raise_for_status()
except requests.HTTPError:
	print("Pagina nu a fost gasita")
time.sleep(1)
print("\nEX 11")

#Exercitiul 11. Toate antenele
response = requests.get(BASE_URL, timeout= TIMEOUT)
for k,v in response.headers.items():
	print(f"{k}: {v}")
time.sleep(1)
print("\nEX 12")

#Exercitiul 12. Metode de dictionar
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Server:", response.headers.get("Server", "lipseste"))
print("Content-Type:", response.headers.get("Content-Type", "lipseste"))
print("content-type",response.headers.get("content-type", "lipseste"))
#ambele variante afiseaza aceasi valoare deaorece response.headers nu este sensitiv si cauta fara sa controleze literele mici sau mari
print("\nEX 13")

#Exercitiul 13. Inlaturirea metodelor sir
time.sleep(1)
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Cuvantul cyber se intalneste de: ",response.text.lower().count("cyber"), "ori")
#poti inlantui lower() cu count() fiindca prima metoda ewturneaza un sir nou de caractere la care se poate aplica cout()
print("\nEX 14")

#Exercitiul 14. Gasirea titlului
time.sleep(1)
response = requests.get(BASE_URL, timeout= TIMEOUT)
html = response.text

start = html.find("<title>") + len("<title>")
end = html.find("</title>")
print("Titlui site-ului este: ",html[start:end].strip())
print("\nEX 15")

#Exercitiul 15. Numararea liniilor
time.sleep(1)
response = requests.get(BASE_URL, timeout=TIMEOUT)
html = response.text
lines = html.splitlines()
linie_max=max(lines, key=len)
print("Numarul de linii", len(lines))
print("Lungime celei mai lungi linii:", len(linie_max))
print("\nEX 16")

#Exercitiul 16. Verificare HTTPS
time.sleep(1)
response = requests.get(BASE_URL, timeout=TIMEOUT)
if response.url.startswith("https://"):
	print("Conexiune securizata")
else: print("Conexiune nesecurizata")
print("\nEX 17")

#Exercitiul 17. Urmarirea redirectionarii
time.sleep(1)
response =requests.get("http://cybercor.org", timeout=TIMEOUT)
for redirect in response.history:
	print(redirect.status_code, redirect.url)
print("URL final:", response.url)
print("\nEX 18")

#Exercitiul 18. HEAD vs GET.
time.sleep(1)
response_head = requests.head(BASE_URL, timeout = TIMEOUT)
time.sleep(1)
response_get = requests.get(BASE_URL, timeout = TIMEOUT)
print("HEAD len:", len(response_head.content))
print("GET len:", len(response_get.content))
#HEAD ia numai antetele, iar get aduce antetele si corpul paginii
print("\nEX 19")

#Exercitiuul 19. Cookie-uri
time.sleep(1)
response = requests.get(BASE_URL, timeout= TIMEOUT)
if response.cookies:
	for cookiee in response.cookies: 
		print(cookie.name, cookie.secure)
else: print("Niciun cookie setat")
print("\nEX 20")

#Exercitiul 20. Sesiuni
time.sleep(1)
session =requests.Session()
session.headers.update({"User-Agent":"WebLab-Burlea-Amelia"})
response = session.get(ECHO_URL + "/headers", timeout =TIMEOUT)
print(response.json())
user_agent = response.json()["headers"]["User-Agent"]
print("User-Agent primit de server:", user_agent)

#response.text nu are paranteze este fiindca este un atribut, iar response.json() are paranteze pentru ca este o metoda
