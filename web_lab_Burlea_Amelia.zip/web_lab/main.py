# Program care foloseste modulul webtools
# Student: Burlea Amelia

import webtools
import time
import requests

BASE_URL = "https://cybercor.org"

print("\nEX 44")
#Exercitiul 44. Crearea unui modul
print(webtools.get_title(webtools.fetch(BASE_URL).text))

print("\nEX 45")
#Exercitiul 45 Importarea anumitor nume
from webtools import get_title, security_headers
#Daca main.py ar avea o functie proprie numite get_title, in fisier ar exista doua nume identice.Fiindca python
#retine doar ultime definitie intalnita , o functie ar inlocuio pe alta fara nici un mesaj de eroare.

print("\nEX 46")
#Exercitiul 46. Blocul main
#Cand rulez direct python webtools.py, Python seteaza __name__ a "__main__", deci conditia din bloc este advarata
#si autotestul ruleaza, iar can webtools este importat din main.py, __name__ este "webtools", conditita este falsa si autotestul nu ruleaza

print("\nEX 47")
#Exercitiul 47. Constante dde modul
from webtools import DEFAULT_HEADERS
print(DEFAULT_HEADERS)

print("\nEX 48")
#Exercitiul 48. Argumente din linia de comanda
import argparse
from webtools import fetch

parser = argparse.ArgumentParser(description="Raport despe un site web")
parser.add_argument("url", help="adresa site-ului, de exmplu https//:cybercor.org")
args = parser.parse_args()

print(get_title(fetch(args.url).text))

time.sleep(1)
print(security_headers(args.url))

print(DEFAULT_HEADERS)

print("\nEX 49")
#Exercitiul 49. Un raport CSV
time.sleep(1)
import csv
from datetime import datetime
from webtools import check_paths

rezultat = check_paths(args.url, ["/", "/robots.txt", "/sitemap.xml"])
with open("report.csv", "w", newline="") as file:
    writer = csv.writer(file)
    writer.writerow(["path", "status", "checked_at"])
    for path, status in rezultat.items():
        writer.writerow([path, status, datetime.now().isoformat()])

print("Salvat in report.csv")

print("\nEX 50")
#Exercitiul 50.Proiect final: raprotul site-ului
from webtools import site_report

site_report(args.url)
