
# Laborator: funcții, metode și importuri pe web
# Student: Burlea Amelia

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde
import time
import requests
import urllib.parse
import re

print("\nEX 35")
#Exercitiul 35. Descompunerea unui URL
parse = urllib.parse.urlparse(BASE_URL + "/path?x=1#top")
print(parse.scheme)
print(parse.netloc)
print(parse.path)
print(parse.query)
print(parse.fragment)

print("\nEX 36")
#Exercitiul 36. Compunerea URL-urilor
print(urllib.parse.urljoin(BASE_URL, "/about"))
print(urllib.parse.urljoin(BASE_URL, "contact.html"))
print(urllib.parse.urljoin(BASE_URL, "../index.html"))

print("\nEX 37")
#Exercitiul 37. Extragerea legaturilor
def extract_links(html):
	"""Returneaza toate legaturile fara duplicate de pe pagina principala"""
	links = re.findall(r'href="([^"]+)"', html)
	return list(dict.fromkeys(links))
time.sleep(1)
response = requests.get(BASE_URL, timeout=TIMEOUT)
html = response.text
links = extract_links(html)
print(links)

print("\nEX 38")
#Exercitiul 38. Interne sau externe
def split_links(links: list, domain: str):
	"""Returneaza legaturile de pe acelasi domeniu si legaturile catre alte site-uri"""
	interne = []
	externe = []
	for link in links:
		complet =urllib.parse.urljoin ("https://" + domain, link)
		if urllib.parse.urlparse(complet).netloc==domain:
			interne.append(complet)
		else: externe.append(complet)
	return interne, externe

lista = ["/about", "contact.html", "../index.html", "https://google.com"]
interne, externe = split_links(lista, "cybercor.org")
print("Interne: ", interne, "Externe:", externe)

print("\nEX 39")
#Exercitiul 39. Propriile metode
from html.parser import HTMLParser

class ImageFinder(HTMLParser):
	def __init__(self):
		super().__init__()
		self.images = []

	def handle_starttag(self, tag, attrs):
		"""Colecteaza atributul src al fiecarui tag <img>."""	
		if tag == "img":
			src = dict(attrs).get("src")
			if src:
				self.images.append(src)

test_html = """
<html><body>
  <img src="/logo.png" alt="Logo">
  <IMG SRC="poza.jpg">
  <img alt="imagine fără src">
  <img src="https://cdn.example.com/banner.webp" />
  <a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""
 
finder = ImageFinder()
finder.feed(test_html)
print(finder.images)
 
assert finder.images == [
    "/logo.png",                            # imagine obișnuită
    "poza.jpg",                             # tag scris cu majuscule
    "https://cdn.example.com/banner.webp",  # tag care se închide singur
], "Parserul nu a găsit exact imaginile așteptate"
print("Testul a trecut!")

time.sleep(1)
response = requests.get(BASE_URL, timeout=TIMEOUT)
finder = ImageFinder()
finder.feed(response.text)
print(len(finder.images), "imagini găsite")
for src in finder.images:
    print(src)
print(response.text.lower().count("<img"))   # pentru comparatie


print("\nEX 40")
#Exercitiul 40. Amprenta paginii
import hashlib
def page_fingerprint(url):
	"""Returneaza amprenta SHA-256 a continutului paginii"""
	response = requests.get(url, timeout=TIMEOUT)
	return hashlib.sha256(response.content).hexdigest()
time.sleep(1)
a = page_fingerprint(BASE_URL)
time.sleep(1)
b= page_fingerprint(BASE_URL)
print(a)
print(b)
print(a==b)
#Amprentele ar fi diferite daca continutul paginii s-ar fi schimbat intre cele doua cereri

print("\nEX 41")
#Exercitiul 41.Salvare JSON
import json
time.sleep(1)
response = requests.get(BASE_URL, timeout = TIMEOUT)
with open("headers.json", "w") as file:
	json.dump(dict(response.headers), file, indent=2)
with open("headers.json", "r") as file:
	incarcat = json.load(file)
print(incarcat["Content-Type"])

print("\nEX 42")
#Exercitul 42.Interogare DNS
import socket
def resolve(hostname):
	"""Returneaza adresa IP a domeniului"""
	host = socket.gethostbyname(hostname)
	return host
print(resolve("cybercor.org"))

print("\nEX 43")
#Exercitiul 43.Expirarea certificatului
import ssl
def cert_days_left(hostname):
	"""Returneaza cate zile mai sunt pana la expirarea certificatului"""
	context = ssl.create_default_context()
	with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
		with context.wrap_socket(sock, server_hostname=hostname) as secure_sock:
			cert = secure_sock.getpeercert()
	expira = ssl.cert_time_to_seconds(cert["notAfter"])
	secunde_ramase = expira - time.time()
	return int(secunde_ramase // 86400)

time.sleep(1)
print("Zile pana la expirarea certificatului:", cert_days_left("cybercor.org"))

#handle_starttag este apelata automat de HTMLParser, din interiorul lui feed(), pentru fiecare tag de deschidere, Eu nu o apelez niciodata direct
